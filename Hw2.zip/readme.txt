CS 156 Intro to AI - 01
Homework 2, 10/06/2014

Andres Chorro - 007340983
Jannette Pham-Le - 007855120
Justin Tieu	- 007789678

1) Program will ask if the user wishes to go first or second. Enter "1" for first and "2" for second.
2) Displayed during the user's turn is the amount of cards left in the deck, the amount of cards in the opponent's deck, the history, the face up card, the user's hand, and all the available moves that the user can play according to the face up card.
3) To play a move, the move must be in one's options.
4) User plays a move by entering 4 numbers separated by either a space, a comma, or parentheses. Any other character entered into the input will result in an invalid move. Best format will be "# # # #", "(#, #, #, #)", or "(#,#,#,#)".
6) If any player plays a skip, a Jack, then the next player must enter a tuple, which will be added into the history clarifying it is a skip. The user's options will display only that tuple if they are skipped.